/**
 * The entrypoint for the action.
 */
const { run } = require('./main')

run()
